# EcoPulse

A premium, responsive climate-action website built with HTML, CSS and vanilla JavaScript.

## Features
- Professional responsive design
- Carbon-footprint educational estimator
- Personalised suggestions
- Saved climate-action checklist using localStorage
- Progress and achievement state
- Rotating climate tips
- Mobile navigation
- GitHub Pages ready

## Run
Keep `index.html`, `style.css`, and `script.js` together and open `index.html`.

## Publish on GitHub Pages
Upload all files to the root of a GitHub repository. Go to Settings → Pages → Deploy from a branch → main → /(root) → Save.

> The footprint estimator uses simplified assumptions for educational demonstration and is not a certified carbon audit.
